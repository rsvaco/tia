package cuadrillas.trabajadores;

import java.util.ArrayList;

import org.opt4j.core.genotype.IntegerGenotype;
import org.opt4j.core.problem.Decoder;

public class CarreterasDecoder implements Decoder<IntegerGenotype, ArrayList<Integer>>{

	@Override
	public ArrayList<Integer> decode(IntegerGenotype genotipo) {
		ArrayList<Integer> fenotipo = new ArrayList<Integer>();
		
		for(int id = 0; id < genotipo.size(); ++id)
		{
			fenotipo.add(genotipo.get(id));
			
		}
		return fenotipo;
	}

}
