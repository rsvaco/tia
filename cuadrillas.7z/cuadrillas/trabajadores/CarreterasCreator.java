package cuadrillas.trabajadores;

import java.util.Random;

import org.opt4j.core.genotype.*;
import org.opt4j.core.problem.*;

public class CarreterasCreator implements Creator<IntegerGenotype>{
	
	public IntegerGenotype create() {
		IntegerGenotype genotipo = new IntegerGenotype(1, Datos.NUM_TURNOS);
		
		genotipo.init(new Random(), Datos.NUM_CUADRILLAS);
		
		return genotipo;
	}
	
}
