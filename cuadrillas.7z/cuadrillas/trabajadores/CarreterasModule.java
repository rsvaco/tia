package cuadrillas.trabajadores;

import org.opt4j.core.problem.ProblemModule;

public class CarreterasModule extends ProblemModule {

	@Override
	protected void config() {
		bindProblem(CarreterasCreator.class, CarreterasDecoder.class, CarreterasEvaluator.class);		
	}

}
