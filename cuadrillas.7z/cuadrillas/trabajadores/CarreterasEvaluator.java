package cuadrillas.trabajadores;

import java.util.ArrayList;

import org.opt4j.core.Objective.Sign;
import org.opt4j.core.Objectives;
import org.opt4j.core.problem.Evaluator;

public class CarreterasEvaluator implements Evaluator<ArrayList<Integer>>{

	@Override
	public Objectives evaluate(ArrayList<Integer> fenotipo) {
		int coste = 0;
		int productividad = 0;
		int[] turnos = new int[Datos.NUM_TURNOS];
		
		for(int id = 0; id < fenotipo.size(); ++id) {
			turnos[fenotipo.get(id) - 1]++;
			coste += Datos.matrizCostes[fenotipo.get(id) - 1][id];
			productividad += Datos.matrizProductividad[fenotipo.get(id) - 1][id];
		}
		
		for(int i = 0; i < Datos.NUM_TURNOS; i++) {
			if(turnos[i] < 3) {
				coste = Integer.MAX_VALUE;
				productividad = 0;
				break;
			}			
		}
		
		Objectives obj = new Objectives();
		obj.add("Distribucion cost - MIN", Sign.MIN, Math.abs(coste));
		obj.add("Distribucion productividad - MAX", Sign.MAX, Math.abs(productividad));
		
		
		return obj;
	}
	
}
